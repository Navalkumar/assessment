window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("myTopnav").style.background = "#029ce0";
    document.getElementById("myTopnav").style.borderBottom = "none";
  } else {
    document.getElementById("myTopnav").style.background = "transparent";
    document.getElementById("myTopnav").style.borderBottom = "1px solid #bfbfbf";
  }
}

function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += "responsive";
  } else {
    x.className = "topnav";
  }
}